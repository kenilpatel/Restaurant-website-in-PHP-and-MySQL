<?php 
    ob_start();
	session_start();
	include 'db.php';
	$bid=$_POST["bid"]; 
	$namep=$_POST["fname"];
	$btp=$_POST["bt"];
	$rpp=$_POST["rp"];
	$bpp=$_POST["pburger"];
	$filep=$_FILES["fileToUpload"]["name"]; 
	$query="select *from hamburger where burgerid='".$bid."'"; 
	echo $query;
	$res=$conn->query($query); 
	$message="";
	$name="";
 	$name="";
	$bt="";
	$rp="";
	$bp="";
	$file=""; 
	while($row=$res->fetch_assoc())
	{
	    echo "kenil";
		$name=$row["name"];
		$bt=$row["bread_type"];
		$rp=$row["recipies"];
		$bp=$row["price"];
		$file=$row["photo"]; 
	} 
	if($filep!="")
	{
		$target_dir = "resources/";
		$target_file = $target_dir.basename($_FILES["fileToUpload"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION)); 
		$file=$target_file; 
	    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
	    if($check !== false) 
	    {
	         
	        $uploadOk = 1;
	    } else 
	    {
	        $message="File is not an image.";
	        $uploadOk = 0;
	    } 
		if (file_exists($target_file)) 
		{
		    $message="Sorry, file already exists.";
		    $uploadOk = 0;
		}  
		else
		{
		    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
		    {
		        $message="Data updated successfully";
		    } 
		    else 
		    {
		        $message="Sorry, there was an error uploading your file.";
		    }
		}
	}
	if($namep!="")
	{
		$name=$namep;
		$message="Data updated successfully";
	}
	if($btp!="")
	{
		$bt=$btp;
		$message="Data updated successfully";
	}
	if($rpp!="")
	{
		$rp=$rpp;
		$message="Data updated successfully";
	}
	if($bpp!="")
	{
		$bp=$bpp;
		$message="Data updated successfully";
	}
    $query1="UPDATE hamburger SET name='".$name."',photo='".$file."',bread_type='".$bt."',recipies='".$rp."',price='".$bp."' where burgerid='".$bid."'";  
	$conn->query($query1); 
	$_SESSION["message"]=$message; 
	header("Location:".$_SERVER['HTTP_REFERER']); 
	
?>