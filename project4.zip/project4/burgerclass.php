<?php 
	class burger
	{
		public $quantity;
		public $extracheese;
		public $remove;
		public $special_instruction;
		public $price;
		public $bid;
		function setdata($quantity=0,$extracheese=0,$remove="yes",$special_instruction="N/A",$price=0,$bid=0,$img="",$name="",$ts="")
		{
			$this->quantity=$quantity;
			$this->extracheese=$extracheese;
			$this->remove=$remove;
			$this->special_instruction=$special_instruction;
			$this->price=$quantity*$price+$extracheese*2*$quantity;
			$this->bid=$bid;
			$this->img=$img;
			$this->name=$name;
			$this->ts=$ts;
		}
		function string()
		{
			return $this->quantity.",".$this->extracheese.",".$this->remove.",".$this->special_instruction.",".$this->price.",".$this->bid.",".$this->img.",".$this->name.",".$this->ts;
		}
	}
?>