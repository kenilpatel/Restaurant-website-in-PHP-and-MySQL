<?php
    ob_start();
	include 'sessioncheck.php';
	$s=ret_session();
	$user=explode(",",$s); 
	if(strcmp($user[0],"user")!=0)
	{ 
		header("location:index.php");
	}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0" >
<head>
	<title>Order History</title>
	<link rel="stylesheet" href="ciudad.css" > 
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script> 

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>

<body> 
	
	<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <a href="menu.php" class="tl">Order Hamburgers</a>
	  <a href="cart.php" class="tl">Cart</a>
	  <a href="orderhistory.php" style="color:red;" class="tl">Order History</a>
	  <a href="Editu.php" class="tl">Edit Data</a> 
	  <a href="editpassword_user.php" class="tl">Change password</a> 
	  <a href="logout.php" class="tl">Logout</a>  
	</div>


	 <div class="chome darken text">
		<div class="topnav" id="myTopnav">
			<a><img src="resources/5.png" id="logo"></img></a>
			 
			<a  href="index.php">INCIO</a>
			<a  href="sobre_nosotros.php">SOBRE NOSOTROS</a>
			<a  href="menu.php">MENU</a>
			<a href="http://txp9131.uta.cloud/blog/">BLOG</a>
			<a  href="contacto.php" >CONTACTO</a> 
		   	<a href="user.php"  ><?php echo $user[1]; ?></a>
		  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
		  	<a href="logout.php" class="tl">LOGOUT</a>
		    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
				    <i class="fa fa-bars"></i>
				  </a>
		</div>

		<div class="triangle1"></div>
		<div class="wrapperincio1_message">  
			<br>
			<br>

			<button onclick="openNav()">Open User Pannel</button>
		</div>
		<div class="triangle2"></div>
	</div>

	<div class="wrappermiddleu">
			<h1>Recent orders</h1> 
			<br>
			<br>
			
			    
			    
			    	<?php 
			    		include 'db.php';
			    		$query="select *from `order` where username='".$user[1]."' ORDER BY orderid DESC"; 
			    		$res=$conn->query($query); 
			    		while($row=$res->fetch_assoc())
						{
							$orderid=$row['orderid'];
							$date=$row['date'];
							$username=$row['username'];
							echo "<figure class=\"border\">";
			   				echo "<img src=\"resources/burguer.png\" class=\"menuimg\">";
			   				echo "<hr>";
							echo "<figcaption class=\"lefts\"> ";
							echo "<h3>Order Number : #$orderid</h3> ";
							echo "<h3>Order Date : $date</h3>";
							$items=$row['items'];
							$burgers=explode(",",$items);
							foreach ($burgers as $key => $value) 
							{
								$burgerdetail=explode(":",$value); 
								if(strcmp($burgerdetail[0],"")!=0)
								{
    								$in=$burgerdetail[0];
    								$qty=$burgerdetail[1];
    								$price=$burgerdetail[2]; 
    								echo "<h3>$in x $qty = $$price </h3>"; 
								}
							} 
							$tot=$row['total_amount'];
							echo "<h3 class=\"red\">Grand Total: $$tot</h3>";
							echo "</figcaption>";
							echo "</figure> ";
						}  
			    	?>   
			    
			 
			  
	</div>
	<?php include 'footer.php'; ?> 
	 
</body> 