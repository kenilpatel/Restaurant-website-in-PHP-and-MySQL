<?php 
    ob_start();
	session_start();
	include 'db.php';
	$bid=""; 
	$namep=$_POST["fname"];
	$btp=$_POST["bt"];
	$rpp=$_POST["rp"];
	$bpp=$_POST["pburger"];
	$filep=$_FILES["fileToUpload"]["name"]; 
	$query1="select *from hamburger order by burgerid DESC";
	echo $query1;
	$res=$conn->query($query1); 
	while($row=$res->fetch_assoc())
	{ 
		$bid=$row["burgerid"]; 
		break;
	} 
	$bid=$bid+1;
	$query2="insert into hamburger(shopid,burgerid) values(1,".$bid.")"; 
	$conn->query($query2);
	$query="select *from hamburger where burgerid='".$bid."'";  
	$res=$conn->query($query); 
	$message="";
	$name="";
 	$name="";
	$bt="";
	$rp="";
	$bp="";
	$file=""; 
	while($row=$res->fetch_assoc())
	{
		$name=$row["name"];
		$bt=$row["bread_type"];
		$rp=$row["recipies"];
		$bp=$row["price"];
		$file=$row["photo"]; 
	} 
	if($namep!="")
	{
		$name=$namep;
		$message="Data updated successfully";
	}
	if($btp!="")
	{
		$bt=$btp;
		$message="Data updated successfully";
	}
	if($rpp!="")
	{
		$rp=$rpp;
		$message="Data updated successfully";
	}
	if($bpp!="")
	{
		$bp=$bpp;
		$message="Data updated successfully";
	}
	if($filep!="")
	{
		$target_dir = "resources/";
		$target_file = $target_dir.basename($_FILES["fileToUpload"]["name"]);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION)); 
		$file=$target_file;   
		if (file_exists($target_file)) 
		{
		    $message="Sorry, file already exists.";
		    $uploadOk = 0;
		}  
		else
		{
		    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
		    {
		        $message="Data updated successfully";
		    } 
		    else 
		    {
		        $message="Sorry, there was an error uploading your file.";
		        $uploadOk = 0;
		    }
		}
	} 
	$query11="UPDATE hamburger SET name='".$name."',photo='".$file."',bread_type='".$bt."',recipies='".$rp."',price='".$bp."' where burgerid='".$bid."'"; 
	echo $message; 
	if($uploadOk ==1)
	{ 
		$conn->query($query11); 
	}
	else
	{
		$query="delete from hamburger where burgerid='".$bid."'";  
		$conn->query($query);  
	}
	$_SESSION["message"]=$message;   
	header("Location:".$_SERVER['HTTP_REFERER']	); 
	
?>