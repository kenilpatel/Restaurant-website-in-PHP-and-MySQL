<?php 
    ob_start();
	session_start();
	include 'db.php';
	$bid=$_GET["bid"];
	$query="delete from hamburger where burgerid='".$bid."'"; 
	$res=$conn->query($query);  
	$_SESSION["message"]="Burger deleted successfully"; 
	header("Location:".$_SERVER['HTTP_REFERER']	);
?>