<?php 
    ob_start();
	include 'db.php';
	$usr=$_POST["usr"];
	$pwd=$_POST["pwd"];
	$query1="select *from admin where username='$usr' and password='$pwd'";
	$query2="select *from users where username='$usr' and password='$pwd'"; 
	$res1=$conn->query($query1);
	$res2=$conn->query($query2);
	$row1 = mysqli_num_rows($res1); 
	$row2 = mysqli_num_rows($res2);  
	session_start();
	if($row1==1)
	{
		$_SESSION['message']="Admin Login Successfully";
		$_SESSION['tu']='admin';
		$_SESSION['tn']=$usr;
	}
	elseif($row2==1)
	{
		$_SESSION['message']="User Login Successfully";
		$_SESSION['tu']='user';
		$_SESSION['tn']=$usr;
	}
	else
	{
		$_SESSION['message']="Login Failed";
		$_SESSION['tu']='';
		$_SESSION['tn']='';
	}
	header("Location:".$_SERVER['HTTP_REFERER']); 
?>