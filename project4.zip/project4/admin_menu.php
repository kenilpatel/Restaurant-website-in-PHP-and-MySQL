<?php 
    ob_start();
	include 'sessioncheck.php';
	$s=ret_session();
	$user=explode(",",$s); 
	if(strcmp($user[0],"admin")!=0)
	{ 
		header("location:index.php");
	}
	include 'db.php'; 
	if(isset($_SESSION['message']))
	{
		if($_SESSION['message']!="")
		{
			echo '<script>alert("'.$_SESSION['message'].'")</script>'; 
		} 
		
	}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0" >
<head>
	<title>Menu</title>
	<link rel="stylesheet" href="ciudad.css" > 
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
<body> 
    <?php  
    	if(isset($_SESSION['message']))
    	{ 
    		if($_SESSION['message']!="")
    		{ 
    			echo "<noscript><h4 style='text-align:center;'>".$_SESSION['message']."</h4></noscript>"; 
    			$_SESSION['message']="";
    		} 
    		
    	}
    ?>
	<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <a href="admin_menu.php" style="color:red;" class="tl">Hamburgers</a>
	  <a href="Edita.php" class="tl">Shop Info</a>
	  <a href="message.php" class="tl">Messages</a> 
	  <a href="logout.php" class="tl">Logout</a>  
	</div>

	<div class="menu darken text">
		<div class="topnav" id="myTopnav">
			<a><img src="resources/5.png" id="logo"></img></a>
			<a   href="index.php">INCIO</a>
			<a  href="sobre_nosotros.php">SOBRE NOSOTROS</a>
			<a  href="menu.php">MENU</a>
			<a href="http://txp9131.uta.cloud/blog/">BLOG</a>
			<a  href="contacto.php">CONTACTO</a> 
		   	<a href="admin.php"><?php echo $user[1]; ?></a>
		   	<a href="logout.php" class="tl">LOGOUT</a>  
		  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
		    <i class="fa fa-bars"></i>
		  </a>
		</div>

		<div class="triangle1"></div>
		<div class="wrapperincio1_message">
			<h4>LAS MEJORES DE LA CIUDAD</h4>
			<h1>Menu</h1> 
			<button onclick="openNav()">Open Admin Pannel</button>
			<a href="#popup2"><button>Add Burger</button></a>
		</div>
		<div class="triangle2"></div>
	</div>

	<div class="middlewrapper" id="navhash">
		 <h2 style="color:white;">Elija su Hamburguesa</h2><br><br>
		 <div class="popular_burger">  
		 	<?php 
		 		$query1="select *from hamburger order by total_sold DESC";
		 		$res1=$conn->query($query1);
			 	$count=0;
			 	while($row=$res1->fetch_assoc())
				{
					 	$photo=$row['photo'];
					 	$name=$row['name'];
					 	$bread_type=$row['bread_type'];
					 	$rec=$row['recipies'];
					 	$price=$row['price'];
					 	$bid=$row['burgerid'];
					 	
					 	echo "<figure>";
					 	echo"<input type='hidden' name='uid' id='uid' value='".$bid."'>";
					 	echo"<input type='hidden' name='breadt' id='breadt".$bid."'' value='".$bread_type."'>";
					 	echo"<input type='hidden' name='rec' id='rec".$bid."' value='".$rec."'>";
					 	echo"<input type='hidden' name='bid' id='bid".$bid."' value='".$bid."'>";
						  echo "<img class= 'burger'  src='".$photo."'></img>";
						  echo "<figcaption><span class='nameb' id='nameb".$bid."'>".$name."</span><br><span class='pb1'>$".$price."</span></figcaption>";
						  echo "<a href='#popup' onclick='constructmi(".$bid.")' class='figa'><button class='ohs'>More Info</button></a><a class='figa' href='#popup1' onclick='constructmi1(".$bid.")'><button class='ohs'>Edit</button></a><a class='figa'  onclick='constructmi2(".$bid.")'><button class='ohs'>Delete</button></a>";
						echo"</figure>";
					 	if($count==3)
					 	{
					 		break;
					 	}
					 	$count=$count+1;
					 	
				} 
		 	?>
	 		 
		 </div>
		 <div class="popular_burger1">  
		 	<h1>Hamburguesas</h1> 
			<?php 
		 		$query2="select *from hamburger order by total_sold DESC";
		 		$res2=$conn->query($query2);
			 	$count=0;
			 	while($row=$res2->fetch_assoc())
				{
					if($count>=4)
					{

					 	$photo=$row['photo'];
					 	$name=$row['name'];
					 	$bread_type=$row['bread_type'];
					 	$rec=$row['recipies'];
					 	$price=$row['price'];
					 	$bid=$row['burgerid'];
					 	$count=$count+1;
					 	echo "<figure class='fp'>";
					 	echo"<input type='hidden' name='uid' id='uid' value='".$bid."'>";
					 	echo"<input type='hidden' name='breadt' id='breadt".$bid."'' value='".$bread_type."'>";
					 	echo"<input type='hidden' name='rec' id='rec".$bid."' value='".$rec."'>";
					 	echo"<input type='hidden' name='bid' id='bid".$bid."' value='".$bid."'>";
						  echo "<img class= 'menuimg'  src='".$photo."'></img>";
						  echo "<figcaption><span class='nameb' id='nameb".$bid."'>".$name."</span><br><span class='pb1'>$".$price."</span></figcaption>";
						  echo "<a href='#popup' onclick='constructmi(".$bid.")' class='figa'><button class='ohs'>More Info</button></a><a href='#popup1' onclick='constructmi1(".$bid.")'><button class='ohs'>Edit</button></a><a  onclick='constructmi2(".$bid.")'><button class='ohs'>Delete</button></a>";
						echo"</figure>";
					 	
					 }	
					 $count=$count+1;
					 	
				} 
		 	?>
			 
		 </div>
	</div>

	<?php include 'footer.php'; ?>  
</div>
 
 
 <div id="popup" class="overlay">
		<div class="popup">
			<img src="resources/Burguer.png" id="burgerlogo"> 
			<a class="close" href="#1">&times;</a>  
			<div class="content">
				<br>
				 <span style="color:black">Name : <span id="burger_name">keni</span></span>
				 <br>
				 <br>
				 <span style="color:black">Bread Type : <span id="burger_bt">kenil</span></span>
				 <br>
				 <br>
				 <span style="color:black">Reciepes :<span id="burger_br">kenil</span></span>
			</div> 
		</div>
	</div>

	<div id="popup1" class="overlay">
		<div class="popup1">
			<img src="resources/Burguer.png" id="burgerlogo"> 
			<a class="close" href="#1">&times;</a> 

			<form id="pform2" action="updateburger.php" method="post" onsubmit="return filevalidate()" enctype="multipart/form-data">
			<div class="content">
				<br>
				<input type="hidden" name="bid" id="bid">
				<span style="color:black">Name : </span>
				<input type="text" name="fname" id="fname">
				<br><br>
				<span style="color:black">Price : </span>
				<input type="number" name="pburger" id="pburger">
				<br><br>
				<span style="color:black">Bread Type : </span>
				<input type="text" name="bt" id="bt">
				<br><br>
				<span style="color:black">Recipes : </span>
				<textarea name="rp" id="rp" rows="4"></textarea>
				<br><br>
				<span style="color:black">Image:</span>
				<input style="color:black;" type="file" name="fileToUpload" id="fileToUpload" >
				<br><br> 
				<div style="text-align:right"><button type="submit" form="pform2">Change Data</button></div>
			</div>
			</form>
		</div>
	</div> 
	<div id="popup2" class="overlay">
		<div class="popup2">
			<img src="resources/Burguer.png" id="burgerlogo"> 
			<a class="close" href="#1">&times;</a> 

			<form id="pform3" action="addburger.php" method="post" onsubmit="return filevalidate1()" enctype="multipart/form-data">
			<div class="content">
				<br>
				<input type="hidden" name="bid" id="bid">
				<span style="color:black">Name : </span>
				<input type="text" name="fname" id="fname" required>
				<br><br>
				<span style="color:black">Price : </span>
				<input type="number" name="pburger" id="pburger" required>
				<br><br>
				<span style="color:black">Bread Type : </span>
				<input type="text" name="bt" id="bt" required>
				<br><br>
				<span style="color:black">Recipes : </span>
				<textarea name="rp" id="rp" rows="4" required></textarea>
				<br><br>
				<span style="color:black">Image:</span>
				<input style="color:black;" type="file" name="fileToUpload" id="fileToUpload" required>
				<br><br> 
				<div style="text-align:right"><button type="submit" form="pform3">Add Data</button></div>
			</div>
			</form>
		</div>
	</div>
	 

</body>  

<script type="text/javascript">
	function filevalidate() 
	{  
		name=document.getElementById("fname").value;
		bt=document.getElementById("bt").value;	
		bp=document.getElementById("pburger").value;	
		rp=document.getElementById("rp").value;
		file=document.getElementById("fileToUpload").value; 
		if(name=="" && bt=="" && rp=="" && file=="" && bp=="")
		{
			alert("Atleast one field should be filled");
			return false;
		}
		return true;
	}
	function constructmi(x)
	{ 
		document.getElementById("burger_name").innerHTML=" "+document.getElementById("nameb"+x).innerHTML;
		document.getElementById("burger_bt").innerHTML=" "+document.getElementById("breadt"+x).value;
		document.getElementById("burger_br").innerHTML=" "+document.getElementById("rec"+x).value;
	}
	function constructmi1(x)
	{ 
		document.getElementById("bid").value=x; 
	}
	function constructmi2(x)
	{  
		if (window.confirm("Do you really want to Delete?")) { 
		  window.open("deleteburger.php?bid="+x,false);
		} 
	}
</script>