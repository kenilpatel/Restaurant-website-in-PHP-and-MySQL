<?php
	include 'db.php';
	$email=$_POST['cemail'];
	$sub=$_POST['csub'];
	$message=$_POST['amsg']; 
	$msgfromuser=$_POST['cmsg']; 
	$query="update message_list set status='read' where email='".$email."' and subject='".$sub."' and message='".$msgfromuser."'"; 
	$conn->query($query); 
	mail($email,$sub,$message);
 	header("Location:message.php");
 	session_start();
	$_SESSION["sentmail"]=0;
?>