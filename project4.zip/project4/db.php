<?php
$servername = "localhost";
$username = "kmp5579_wp1";
$password = "gS6o^3rz@qBb"; 
$db="kmp5579_wp1";
$conn = new mysqli($servername, $username, $password,$db); 
if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error;
}  
?>