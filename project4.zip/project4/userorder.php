<?php 
    ob_start();
	include 'sessioncheck.php';
	$s=ret_session();
	$user=explode(",",$s); 
	include 'db.php';
 	$orderid=time();
 	$date=date("Y/m/d"); 
 	$cart=$_COOKIE["cart".$_SESSION['tn']]; 
	$array=explode("\n",$cart);   
	$tot_price=0;
	$cnt=0;
	$orderstring="";
	$username=$user[1]; 
	foreach ($array as $key => $value) 
	{   
		if(strcmp($value,"")!=0)
		{  
			$cnt++;
			$burger=explode(",",$value); 
			$qty1=$burger[0];
			$ec=$burger[1];
			$nc=$burger[2];
			$si=$burger[3];
			$price=$burger[4];
			$img=$burger[6];
			$name=$burger[7]; 
			$orderstring=$orderstring.$name;
			if($ec!=0)
			{
				$orderstring=$orderstring." with $ec extra slice of cheese";
			}
			else if($nc=="yes")
			{
				$orderstring=$orderstring." with no cheese";
			}
			else
			{
				$orderstring=$orderstring." with normal cheese";
			}
			$orderstring=$orderstring.":$qty1";
			$orderstring=$orderstring.":$price";
			$orderstring=$orderstring.",";
			$tot_price=$tot_price+$price;
			$query_sold="select total_sold from hamburger where name='".$name."'"; 
			$res=$conn->query($query_sold); 
    		while($row=$res->fetch_assoc())
			{
				$total_sold=$row["total_sold"];
			}
			$total_sold=$total_sold+$qty1;
			$update_query="update hamburger set total_sold=".$total_sold." WHERE name='".$name."'"; 
			$res=$conn->query($update_query);
		}
	} 
	$orderstring=$orderstring;
	$len=strlen($orderstring); 
	$orderstring[$len-1]=""; 
	$orderfinal=explode(",",$orderstring);  
	$msgbody="<table style=\"text-align:left;border:1px solid black;border-collapse: collapse;\"><tr><th style=\"padding:15px;border:1px solid black;\">Item_Name</th><th style=\"padding:15px;border:1px solid black;\">Quantity</th><th style=\"padding:15px;border:1px solid black;\">Price</th></tr>";
	foreach ($orderfinal as $key => $value) 
	{   
		if(strcmp($value,"")!=0)
		{
			$burgerdetail=explode(":",$value);
			$in=$burgerdetail[0];
			$qty=$burgerdetail[1];
			$price=$burgerdetail[2]; 
			$msgbody=$msgbody."<tr><td style=\"padding:15px;border:1px solid black;\">".$in."</td><td style=\"padding:15px;border:1px solid black;\">".$qty."</td><td style=\"padding:15px;border:1px solid black;\">$".$price."</td></tr>"; 
		}
	}
	$msgbody=$msgbody."<tr><td style=\"padding:15px;border:1px solid black;\" colspan=\"3\">Total Price : $$tot_price</td></tr>";
	$msgbody."</table>";
	echo $msgbody; 
	$s=ret_session();
	$user=explode(",",$s);
	$query11="select *from users where username='".$user[1]."'";
	$res=$conn->query($query11);
	$email="";
	while($row=$res->fetch_assoc())
	{
		$email=$row["email"];
	}
	$headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	mail($email,"Regarding Recent Order",$msgbody,$headers);
	$query="insert into `order` (orderid,username,items,total_amount,date) values(\"$orderid\",\"$username\",\"$orderstring\",\"$tot_price\",\"$date\")";
	$conn->query($query);
	setcookie("cart".$_SESSION['tn'], "", time() + (86400 * 30), "/");
	$_SESSION["message"]="Order placed successfully thanks for the order"; 
	header("Location:".$_SERVER['HTTP_REFERER']	);
 ?>