<?php  
	include 'db.php';
	$query="select *from shop";
	$res=$conn->query($query); 
	while($row=$res->fetch_assoc())
	{
		$telno=$row['telephone_no'];
		$email=$row['email'];
		$add=$row['address'];
	}  
	echo "<div class=\"incio_footer darken text\" >";
		echo "<div class=\"wrapperfooter\">";
				echo "<div class=\"triangle\"></div>";
				echo "<img src=\"resources/5.png\"></img>" ;
				echo "<p class=\"highlight\">Habla a:</p>";
				echo "<p>".$add."</p>"  ;
				echo "<p class=\"highlight\">Telefono:</p>";
				echo "<p>".$telno."</p>"  ; 
				echo "<p class=\"highlight\">Correo:</p>";
				echo "<p>".$email."</p>"  ;  
				echo "<a href=\"#\" class=\"fa fa-pinterest\"></a>";
				echo "<a href=\"#\" class=\"fa fa-facebook\"></a>";
				echo "<a href=\"#\" class=\"fa fa-twitter\"></a> ";
				echo "<a href=\"#\" class=\"fa fa-instagram\"></a>";
				echo "<a href=\"#\" class=\"fa fa-linkedin\"></a>";
				echo "<a href=\"#\" class=\"fa fa-vimeo\"></a> "  ;
				echo "<h5>Copyright &copy;2020 Todos los derechos reservados | Este sitio esta hecho con &hearts; por DiazApps</h5>";
				echo "<br>";
		echo "</div>" ;
	echo "</div>";

?>
