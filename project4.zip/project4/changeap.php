<?php
    ob_start();
	include 'db.php'; 
	include 'sessioncheck.php';
	$pwd=$_POST['pwd1'];
	$s=ret_session();
	$user=explode(",",$s); 
	session_start();
	$query1="UPDATE admin SET password='".$pwd."' where username='".$user[1]."'"; 
	$conn->query($query1); 
	$_SESSION["message"]="password changed successfully"; 
	header("Location:".$_SERVER['HTTP_REFERER']	); 
?>