<?php
    ob_start();
	include 'db.php';	
	session_start();
	$name=$_POST['name'];
	$mail1=$_POST['mail'];
	$pwd1=$_POST['pwd1'];
    $pwd2=$_POST['pwd2'];
	$address=$_POST['address']; 
    $regex='/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/';
    
    if($name=="" || $mail1=="" || $pwd1=="" || $pwd2=="" || $address=="")
    {
        
        $_SESSION["message"]="Please fill all the fields";  
        header("Location:".$_SERVER['HTTP_REFERER'] );
    }
    else
    {
        if(strcmp($pwd1,$pwd2)==0)
        {
            if (strlen($pwd1)>=8 && strlen($pwd1)<=10) 
            {
                if(preg_match($regex, $mail1))
                {
                    try
                    {
                        $query1="select *from users where email='$mail1'";
                        echo $query1;
                        $res=$conn->query($query1);
                        $nr=mysqli_num_rows ($res);
                        if($nr!=0)
                        {
                            $_SESSION["message"]="User with same email address already registered";
                            header("Location:".$_SERVER['HTTP_REFERER'] );  
                        }
                        else
                        {
                            $query1="select *from users where username='$name'";
                            $res=$conn->query($query1);
                            $nr=mysqli_num_rows ($res);
                            if($nr!=0)
                            {
                                $_SESSION["message"]="User with same username address already registered";
                                header("Location:".$_SERVER['HTTP_REFERER'] );  
                            }
                            else
                            {
                                
                                $_SESSION["message"]="Registration done successfully";
                                echo "done";
                                $Body="Hello,$name Thank you so much for your registration with ibras hamburgers now you can login to the website and order hamburgers";
                                mail($mail1,"Thank you for registration..",$Body); 
                                $query="insert into users values('$name','$pwd1','$address','$mail1')";
                                echo $query;
                                $conn->query($query); 
                                $_SESSION['message']="Registration successfully done"; 
                                header("Location:".$_SERVER['HTTP_REFERER'] );
                            }
                        }
                    }
                    catch(Exception $e)
                    {
                        echo $e->getMessage();
                        $_SESSION['message']="Please enter proper email address"; 
                        header("Location:".$_SERVER['HTTP_REFERER'] );
                    }
                } 
                else
                {
                    $_SESSION["message"]="Please enter proper email address";  
                    header("Location:".$_SERVER['HTTP_REFERER'] );
                }
                
            }
            else
            {
                $_SESSION["message"]="Please should be between 8 to 10 length";  
                header("Location:".$_SERVER['HTTP_REFERER'] );
            }
        } 
        else
        {
             $_SESSION["message"]="Password should be same in both fields";  
            header("Location:".$_SERVER['HTTP_REFERER'] );
        }
    
	}
?>