<?php 
    ob_start();
	include 'db.php';
	session_start();
	$email=$_POST["fe"];
	$query1="select *from users where email='$email'";
	$res=$conn->query($query1);
	$nr=mysqli_num_rows ($res); 
	if($nr==0)
	{
		$_SESSION["message"]="User with this email does not found";
		header("Location:".$_SERVER['HTTP_REFERER']	);
	}
	else
	{
		$_SESSION["message"]="Password is sent to your email";
		$query1="select password from users where email='$email'";
		$res=$conn->query($query1);
		while($row=$res->fetch_assoc())
		{
			$pwd=$row["password"];
		}
		$Subject="Regarding recent password reset"; 
		$Body="Your password is $pwd. We request you to change your password as soon as possible after login";
		$headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		mail($email,$Subject,$Body,$headers);
		header("Location:".$_SERVER['HTTP_REFERER']	);	
	} 
?>