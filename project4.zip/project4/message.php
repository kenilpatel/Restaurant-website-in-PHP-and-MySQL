<?php 
    ob_start();
	include 'sessioncheck.php';
	$s=ret_session();
	$user=explode(",",$s); 
	if(strcmp($user[0],"admin")!=0)
	{ 
		header("location:index.php");
	}
	include 'db.php';
	 
	if(isset($_SESSION['sentmail']))
	{
		if($_SESSION['sentmail']==0)
		{
			echo '<script>alert("Mail successfully sent")</script>';
			
		} 
		
	}

?>
<meta name="viewport" content="width=device-width, initial-scale=1.0" >
<head>
	<title>Messages</title>
	<link rel="stylesheet" href="ciudad.css" > 
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script> 

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>

<body> 
	<?php  
    	if(isset($_SESSION['sentmail']))
    	{ 
    		if($_SESSION['sentmail']==0)
    		{ 
    			echo "<noscript><h4 style='text-align:center;'>"."Mail successfully sent"."</h4></noscript>"; 
    			$_SESSION['sentmail']=1;
    		} 
    		
    	}
    ?>
	<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <a href="menu.php" class="tl">Hamburgers</a>
	  <a href="Edita.php" class="tl">Shop Info</a>
	  <a href="message.php" style="color:red;" class="tl">Messages</a>
	  <a href="editpassword_admin.php" class="tl">Change password</a> 
	  <a href="logout.php" class="tl">Logout</a>  
	</div>


	 <div class="chome darken text">
		<div class="topnav" id="myTopnav">
			<a><img src="resources/5.png" id="logo"></img></a>
			 
			<a  href="index.php">INCIO</a>
			<a  href="sobre_nosotros.php">SOBRE NOSOTROS</a>
			<a  href="menu.php">MENU</a>
			<a href="http://txp9131.uta.cloud/blog/">BLOG</a>
			<a  href="contacto.php" >CONTACTO</a> 
		   	<a href="admin.php" style="color:red;"><?php echo $user[1]; ?></a>
		   	<a href="logout.php" class="tl">LOGOUT</a>  
		  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
		    <i class="fa fa-bars"></i>
		  </a>
		</div>

		<div class="triangle1"></div>
		<div class="wrapperincio1_message">  
			<br>
			<br>

			<button onclick="openNav()">Open admin Pannel</button>
		</div>
		<div class="triangle2"></div>
	</div>

	<div class="wrappermiddleu" id="recentm">
			<h1>Recent Messages</h1>   
			 <?php
			 	$query1="select *from message_list where status='unread'"; 
			 	$res1=$conn->query($query1);
			 	$count=0;

			 	while($row=$res1->fetch_assoc())
				{
					 	echo "<figure class='border'>";
					    echo "<img src='resources/burguer.png' class='menuimg'>";
					    echo "<hr>";
					    echo "<figcaption class='lefts' style='text-align:center;'> ";
					      echo "<h3>Name : <span id=n".$count.">".$row['name']."</span></h3> ";
					      echo "<h3>Email : <span id=e".$count.">".$row['email']."</span></h3>" ;
					      echo "<h3 style='text-align:center;'>Sub : <span id=s".$count.">".$row['subject']."</span></h3> ";
					      echo "<h3 style='text-align:center;'>Message : <span id=m".$count.">".$row['message']."</span></h3> ";
					      echo "<a href='#popup1' onclick='constructreply(".$count.")'><button>Reply</button></a>";
					    echo "</figcaption>";
					 	echo "</figure>";
					 	$count=$count+1;
				}
				if($count==0)
				{
					echo "<br><h1 class='simple' style='font-size:20px;	'>No new messages</h1>";
				}
			 ?>
			
	</div>
	<?php include 'footer.php'; ?>  
	<div id="popup1" class="overlay">
		<div class="popup1">
			<img src="resources/Burguer.png" id="burgerlogo">
			<a class="close" href="#1">&times;</a> 
			<form id="pform1" method="post" action="mail.php" onsubmit="return validateadmin()">
			<div class="content"> 
				<span style="color:black">Customer Email:</span>
				<br> 
				<input type="email" name="cemail" id="cemail" readonly required>
				<br>
				<br>
				<span style="color:black">Subject:</span>
				<br> 
				<input type="hidden" name="cmsg" id="cmsg">
				<input type="text" name="csub" id="csub" readonly required>
				<br>
				<br>
				<span style="color:black">Message:</span>
				<br> 
				<textarea placeholder="Message" id="amsg" name="amsg" rows="10" required></textarea>
				<div style="text-align:right"><br><br><button type="submit"  form="pform1">Reply</button></div>
			</div>
			</form>
		</div>
	</div>

	 
</body> 

<script type="text/javascript">
	function constructreply(x) 
	{
	  idg1="n"+x;
	  idg2="e"+x;
	  idg3="s"+x;
	  idg4="m"+x;
	  name=document.getElementById(idg1).textContent;
	  email=document.getElementById(idg2).textContent;
	  sub=document.getElementById(idg3).textContent;  
	  message=document.getElementById(idg4).textContent; 
	  document.getElementById("cemail").value=email;
	  document.getElementById("csub").value=sub;
	  document.getElementById("cmsg").value=message;
	}
	function validateadmin()
	{
		email1=document.getElementById("cemail").value;
		sub1=document.getElementById("csub").value;	
		message1=document.getElementById("cmsg").value;
		msg=document.getElementById("amsg").value;
		if(email1=="" || sub1=="" || message1=="" || msg=="")
		{
			alert("All field should be filled");
			return false;
		}
		return true;
	}
</script>