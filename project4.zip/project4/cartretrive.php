<?php  
    ob_start();
	if(!isset($_COOKIE["cart".$_SESSION['tn']])) 
	{
		echo "<h3>Cart is empty</h3>"; 
	}
	else
	{
		$cart=$_COOKIE["cart".$_SESSION['tn']]; 
		echo "cart".$cart;
		$array=explode("\n",$cart);  
		$tot_price=0;
		foreach ($array as $key => $value) {  
			$burger=explode(",",$value); 
			$qty1=$burger[0];
			$ec=$burger[1];
			$nc=$burger[2];
			$si=$burger[3];
			$price=$burger[4];
			$img=$burger[6];
			$name=$burger[7]; 
			echo "<div class=\"cart_burger\">  ";
			echo "<figure>";
			  echo "<img class= \"menuimg\"  src=\"".$img."\"></img>";
			  echo "<figcaption> <span class=\"nameb\">Name : ".$name."</span><br><span class=\"pb\">Price : $".$price/$qty1." X ".$qty1."</span><br><span class=\"pb\">"."Extra cheese :"."".$ec." slice </span><br><span class=\"pb\">Special Instruction : ".$si."</span><br><br><button onclick=deletecart(".$value.") class=\"oh\">Delete</button></figcaption>"; 
			echo "</figure>";
			echo "</div>";
			$tot_price=$tot_price+$price;
		}
		echo "<br><div class=\"finalprice\">";
		     	echo "<h1>Your Cart Value is : $".$tot_price."</h1>";
		     	echo "<button>Want to add something</button>";
		     	echo "<button class=\"gb\">Proceed to checkout</button>";
		echo "</div>";
	}
?>