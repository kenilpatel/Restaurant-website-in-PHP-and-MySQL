<?php 
    ob_start();
	include 'db.php';
	$old=$_POST["oldusername"]; 
	$query="select *from users where username='".$old."'";
	$res=$conn->query($query); 

	session_start();
	while($row=$res->fetch_assoc())
	{
		$usn=$row['username'];
		$email=$row['email'];
		$add=$row['address'];
	} 
	if($_POST['email']!="")
	{
		$email=$_POST['email'];
	}
	if($_POST['username']!="")
	{ 
		$usn=$_POST['username'];
		$_SESSION['tn']=$usn;
		$query2="UPDATE order SET username='".$usn."' where username='".$old."'";
		$conn->query($query2); 
	}
	if($_POST['address']!="")
	{
		$add=$_POST['address'];
	}
	$query1="UPDATE users SET username='".$usn."',email='".$email."',address='".$add."' where username='".$old."'";
	$conn->query($query1);  
	$_SESSION["message"]="Data changed successfully";
	header("Location:".$_SERVER['HTTP_REFERER']);
?>