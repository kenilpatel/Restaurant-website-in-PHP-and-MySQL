<?php 
    ob_start();
	session_start();
	include 'burgerclass.php';
	include 'db.php';
	$bid=$_POST["bid"];
	$qty=$_POST["qty"];
	$qty1=$_POST["qty1"];
	$remove_cheese=$_POST["cheese"];
	if(strcmp($_POST["si"],"")!=0)
	{
		$si=$_POST["si"];
	}
	else
	{
		$si="N/A";
	}
	$query="select price from hamburger where burgerid=".$bid; 
	$res2=$conn->query($query); 
	while($row=$res2->fetch_assoc())
	{
		$price=$row['price'];
	} 
	$query="select photo from hamburger where burgerid=".$bid; 
	$res2=$conn->query($query); 
	while($row=$res2->fetch_assoc())
	{
		$img=$row['photo'];
	} 
	$query="select name from hamburger where burgerid=".$bid; 
	$res2=$conn->query($query); 
	while($row=$res2->fetch_assoc())
	{
		$name=$row['name'];
	} 
	$burger1=new burger();
	$burger1->setdata($qty,$qty1,$remove_cheese,$si,$price,$bid,$img,$name,time());
	echo $burger1->string();
	if(!isset($_COOKIE["cart".$_SESSION['tn']])) 
	{  
	    echo "cart".$_SESSION['tn'];
		setcookie("cart".$_SESSION['tn'], $burger1->string(), time() + (86400 * 30), "/"); 
	} 
	else 
	{
	     echo "cart".$_SESSION['tn'];
	    $arrayobject=$_COOKIE["cart".$_SESSION['tn']]; 
	    $arrayobject=$arrayobject."\n".$burger1->string();
		setcookie("cart".$_SESSION['tn'], $arrayobject, time() + (86400 * 30), "/");
	}
	$_SESSION["message"]="Burger added to cart successfully"; 
	header("Location:".$_SERVER['HTTP_REFERER']	);
?>