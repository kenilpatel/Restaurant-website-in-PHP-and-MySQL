<?php 
    ob_start();
	include 'sessioncheck.php';
	$s=ret_session();
	$user=explode(",",$s); 
	if(strcmp($user[0],"user")!=0)
	{ 
		header("location:index.php");
	}
	include 'db.php'; 
	if(isset($_SESSION['message']))
	{
		if($_SESSION['message']!="")
		{
			echo '<script>alert("'.$_SESSION['message'].'")</script>'; 
		} 
		
	}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0" >
<head>
	<title>Menu</title>
	<link rel="stylesheet" href="ciudad.css" > 
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
<body> 
    <?php  
    	if(isset($_SESSION['message']))
    	{ 
    		if($_SESSION['message']!="")
    		{ 
    			echo "<noscript><h4 style='text-align:center;'>".$_SESSION['message']."</h4></noscript>"; 
    			$_SESSION['message']="";
    		} 
    		
    	}
    ?>
	<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <a href="user_menu.php" class="tl">Order Hamburgers</a>
	  <a href="cart.php" class="tl">Cart</a>
	  <a href="orderhistory.php" class="tl">Order History</a>
	  <a href="Editu.php" class="tl">Edit Data</a> 
	  <a href="logout.php" class="tl">Logout</a>  
	</div>

	<div class="menu darken text">
		<div class="topnav" id="myTopnav">
			<a><img src="resources/5.png" id="logo"></img></a>
			<a   href="index.php">INCIO</a>
			<a  href="sobre_nosotros.php">SOBRE NOSOTROS</a>
			<a  style="color:red;"  href="umenu.php">MENU</a>
			<a href="http://txp9131.uta.cloud/blog/">BLOG</a>
			<a  href="contacto.php">CONTACTO</a> 
		   	<a href="user.php"><?php echo $user[1]; ?></a>
		   	<a href="logout.php" class="tl">LOGOUT</a>
		  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
		    <i class="fa fa-bars"></i>
		  </a>
		</div>

		<div class="triangle1"></div>
		<div class="wrapperincio1_message">
			<h4>LAS MEJORES DE LA CIUDAD</h4>
			<h1>Menu</h1> 
			<button onclick="openNav()">Open User Pannel</button>
		</div>
		<div class="triangle2"></div>
	</div>

	<div class="middlewrapper" id="navhash">
		 <h2 style="color:white;">Elija su Hamburguesa</h2><br><br>
		 <div class="popular_burger">   
			<?php 
		 		$query2="select *from hamburger order by total_sold DESC";
		 		$res2=$conn->query($query2); 
		 		$count=0;
			 	while($row=$res2->fetch_assoc())
				{ 
					if($count<=3)
					{
					 	$photo=$row['photo'];
					 	$name=$row['name'];
					 	$bread_type=$row['bread_type'];
					 	$rec=$row['recipies'];
					 	$price=$row['price'];
					 	$bid=$row['burgerid']; 
					 	echo "<figure class='fp'>";
					 	echo"<input type='hidden' name='uid' id='uid' value='".$bid."'>";
					 	echo"<input type='hidden' name='breadt' id='breadt".$bid."'' value='".$bread_type."'>";
					 	echo"<input type='hidden' name='rec' id='rec".$bid."' value='".$rec."'>";
					 	echo"<input type='hidden' name='bid' id='bid".$bid."' value='".$bid."'>";
						  echo "<img class= 'burger'  src='".$photo."'></img>";
						  echo "<figcaption><span class='nameb' id='nameb".$bid."'>".$name."</span><br><span class='pb1'>$".$price."</span></figcaption>";
						  echo "<a href='#popup' onclick='constructmi(".$bid.")' class='figa'><button class='ohs'>More Info</button></a><a href='#popup1' onclick='constructmi1(".$bid.")'><button class='ohs'>Order</button></a>";
						echo"</figure>"; 
					}
					$count=$count+1;
					 	
				} 
		 	?>   
		 </div>
		 <div class="popular_burger1">  
		 	<h1>Hamburguesas</h1>
	 		<?php 
		 		$query2="select *from hamburger order by total_sold DESC";
		 		$res2=$conn->query($query2); 
		 		$count=0;
			 	while($row=$res2->fetch_assoc())
				{ 
					if($count>3)
					{
					 	$photo=$row['photo'];
					 	$name=$row['name'];
					 	$bread_type=$row['bread_type'];
					 	$rec=$row['recipies'];
					 	$price=$row['price'];
					 	$bid=$row['burgerid']; 
					 	echo "<figure class='fp'>";
					 	echo"<input type='hidden' name='uid' id='uid' value='".$bid."'>";
					 	echo"<input type='hidden' name='breadt' id='breadt".$bid."'' value='".$bread_type."'>";
					 	echo"<input type='hidden' name='rec' id='rec".$bid."' value='".$rec."'>";
					 	echo"<input type='hidden' name='bid' id='bid".$bid."' value='".$bid."'>";
						  echo "<img class= 'menuimg'  src='".$photo."'></img>";
						  echo "<figcaption><span class='nameb' id='nameb".$bid."'>".$name."</span><br><span class='pb1'>$".$price."</span></figcaption>";
						  echo "<a href='#popup' onclick='constructmi(".$bid.")' class='figa'><button class='ohs'>More Info</button></a><a href='#popup1' onclick='constructmi1(".$bid.")'><button class='ohs'>Order</button></a>";
						echo"</figure>"; 
					}
					$count=$count+1;
					 	
				} 
		 	?>
			 
		 </div>
	</div>

	
</div>
 <?php include 'footer.php'; ?>
 
<div id="popup" class="overlay">
		<div class="popup">
			<img src="resources/Burguer.png" id="burgerlogo"> 
			<a class="close" href="#1">&times;</a>  
			<div class="content">
				<br>
				 <span style="color:black">Name : <span id="burger_name">keni</span></span>
				 <br>
				 <br>
				 <span style="color:black">Bread Type : <span id="burger_bt">kenil</span></span>
				 <br>
				 <br>
				 <span style="color:black">Reciepes :<span id="burger_br">kenil</span></span>
			</div> 
		</div>
	</div>

	<div id="popup1" class="overlay">
		<div class="popup1">
			<img src="resources/Burguer.png" id="burgerlogo"> 
			<a class="close" href="#1">&times;</a> 
			<form id="pform2" action="addtocart.php" method="post">
			<div class="content">
				<br>
				<input type="hidden" name="bid" id="bid">
				<span style="color:black;">Quantity</span>
				<input type="number" id="qty" name="qty" value="1" min=1 max=10>
				<br>
				<br>
				<span style="color:black;">Remove Cheese</span>
				<input type="radio" id="cheese" name="cheese" value="yes"><span style="color:black;">Yes</span>
				<input type="radio" id="cheese" name="cheese" checked value="no"><span style="color:black;">No</span>
				<br>
				<br>
				<span style="color:black;">Extra Cheese</span>
				<input id="qty1" type="number" name="qty1" value="0" min=0 max=3>
				<br>
				<br>
				<span style="color:black;">Special Instruction</span>
				<textarea name="si" id="si" rows="4"></textarea>
				<div style="text-align:right"><button type="submit" form="pform2">Add to Cart</button></div>
			</div>
			</form>
		</div>
	</div> 
</body>  

<script type="text/javascript">
	function constructmi(x)
	{ 
		document.getElementById("burger_name").innerHTML=" "+document.getElementById("nameb"+x).innerHTML;
		document.getElementById("burger_bt").innerHTML=" "+document.getElementById("breadt"+x).value;
		document.getElementById("burger_br").innerHTML=" "+document.getElementById("rec"+x).value;
	}
	function constructmi1(x)
	{ 
		document.getElementById("bid").value=x; 
	}
</script> 