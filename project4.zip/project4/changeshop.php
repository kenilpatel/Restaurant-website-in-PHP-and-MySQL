<?php
    ob_start();
	include 'db.php';
	$query="select *from shop";
	$res=$conn->query($query); 
	while($row=$res->fetch_assoc())
	{
		$telno=$row['telephone_no'];
		$email=$row['email'];
		$add=$row['address'];
	}  
	if($_POST['email']!="")
	{
		$email=$_POST['email'];
	}
	if($_POST['tel']!="")
	{
		$telno=$_POST['tel'];
	}
	if($_POST['address']!="")
	{
		$add=$_POST['address'];
	}
	$query1="UPDATE shop SET telephone_no='".$telno."',email='".$email."',address='".$add."' where shopid='1'"; 
	$conn->query($query1); 
	$_SESSION["message"]="Data updated successfully"; 
	header("Location:".$_SERVER['HTTP_REFERER']	); 
	session_start();
	

?>