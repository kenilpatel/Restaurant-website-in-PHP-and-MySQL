<?php
    ob_start();
    session_start();
	include 'db.php';
	$name=$_POST['name'];
	$email=$_POST['email'];
	$sub=$_POST['sub'];
	$msg=$_POST['msg'];
	$regex='/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/';
	if($name=="" || $email=="" || $sub=="" || $msg=="")
	{
		
		$_SESSION["message"]="Please fill all the fields";  
		header("Location:".$_SERVER['HTTP_REFERER']	);
	}
	else if(preg_match($regex, $email))
	{
		$status="unread";
		$query="INSERT INTO message_list(name, email, subject,message,status) VALUES ('".$name."', '".$email."', '".$sub."','".$msg."','".$status."')";
		$conn->query($query); 
		$_SESSION["message"]="Message sent successfully";  
		header("Location:".$_SERVER['HTTP_REFERER']	);
	}
	else
	{ 
		$_SESSION["message"]="Email address should be in the format aaa@gmail.com";  
		header("Location:".$_SERVER['HTTP_REFERER']	);
	} 
?>