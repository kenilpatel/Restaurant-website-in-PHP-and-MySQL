<?php 
    ob_start();
	$data=$_GET['datad'];
	$data = str_replace('_', ' ', $data);
	session_start();
	if(isset($_COOKIE["cart".$_SESSION['tn']]))
	{
		
		$cn=$_COOKIE["cart".$_SESSION['tn']];
		echo $cn."<br><br><br>"; 
		$cn = str_replace($data, '', $cn); 
		echo $cn;
		setcookie("cart".$_SESSION['tn'], $cn, time() + (86400 * 30), "/");
	}  
	$_SESSION["message"]="Burger deleted from cart successfully"; 
	header("Location:".$_SERVER['HTTP_REFERER']	);
?>