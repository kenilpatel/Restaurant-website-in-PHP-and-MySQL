<?php 
    ob_start();
	include 'sessioncheck.php';
	$s=ret_session();
	$user=explode(",",$s); 
	if(strcmp($user[0],"user")!=0)
	{ 
		header("location:index.php");
	}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0" >
<head>
	<title>User</title>
	<link rel="stylesheet" href="ciudad.css" > 
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script> 

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>

<body> 
	
	<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <a href="user_menu.php" class="tl">Order Hamburgers</a>
	  <a href="cart.php" class="tl">Cart</a>
	  <a href="orderhistory.php" class="tl">Order History</a>
	  <a href="Editu.php" class="tl">Edit Data</a> 
	  <a href="#" class="tl">Logout</a>  
	</div>


	 <div class="contacto darken text">
		<div class="topnav" id="myTopnav">
			<a><img src="resources/5.png" id="logo"></img></a>
			 
			<a  href="index.php">INCIO</a>
			<a  href="sobre_nosotros.php">SOBRE NOSOTROS</a>
			<a  href="menu.php">MENU</a>
			<a href="http://txp9131.uta.cloud/blog/">BLOG</a>
			<a  href="contacto.php" >CONTACTO</a> 
		   	<a href="user.php" style="color:red;"><?php echo $user[1]; ?></a>

		  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
		    <i class="fa fa-bars"></i>
		  </a>
		  <a href="logout.php" class="tl">LOGOUT</a>
		</div>

		<div class="triangle1"></div>
		<div class="wrapperincio1_message">  
			<br>
			<br>

			<button onclick="openNav()">Open User Pannel</button>
		</div>
		<div class="triangle2"></div>
	</div>

	<div class="middlewrapper">
		<img src="resources/Burguer.png" id="burgerlogo"></img>
		<h1>Welcome, User</h1> 
		  
	</div>
	<?php include 'footer.php'; ?>
	 
	  
</body> 