<?php   
    ob_start();
	session_start();
	$_SESSION['message']="Logout Successfully";
	$_SESSION['tu']='';
	$_SESSION['tn']=''; 
	header("Location:".$_SERVER['HTTP_REFERER']); 
?>